# Pixeldrain Uploader

Upload files to Pixeldrain from the GNOME top panel.

## Features

- Left click the panel icon to pick and upload files
- Right click the panel icon to open the popup menu
- Show recent uploads in the popup
- Copy uploaded links from the popup
- Store the Pixeldrain API key in extension preferences

## Notes

- The extension uses the Pixeldrain API and requires a user API key
- Uploaded file links are copied to the clipboard automatically after a successful upload
- Recent uploads are stored locally in the extension settings

## Preferences

Open the extension preferences from GNOME Extensions and set your Pixeldrain API key.
